package com.tcs.LibraryManagementSystem.utility;

public class ResponceUpdate {

    public static String AUTHOR_UPDATE_RESPONSE_MESSAGE;
    public static String BOOK_UPDATE_RESPONSE_MESSAGE;
    public static String GENRE_UPDATE_RESPONSE_MESSAGE;
    public static String BRANCH_UPDATE_RESPONSE_MESSAGE;
    public static String BORROWER_UPDATE_RESPONSE_MESSAGE;

    public static String LIB_BRANCH_UPDATE_RESPONSE_MESSAGE;
    public static Boolean DELETED_FALG =true;
    public static String VALIDATE_RESPONSE = "should not empty..please retry!";
    /*
    Edureka Instructor To Everyone
12:08:02 pm
EI
https://github.com/akash-coded/spring-framework/
https://github.com/akash-coded/spring-framework/discussions/145
@Entity
@IdClass(AccountId.class)
public class Account {
    @Id
    private String accountNumber;

    @Id
    private String accountType;

    // other fields, getters and setters
}
@Embeddable
public class BookId implements Serializable {
    private String title;
    private String language;

    // default constructor

    public BookId(String title, String language) {
        this.title = title;
        this.language = language;
    }

    // getters, equals() and hashCode() methods
}
@Entity
public class Book {
    @EmbeddedId
    private BookId bookId;

    // constructors, other fields, getters and setters
}
     */
}

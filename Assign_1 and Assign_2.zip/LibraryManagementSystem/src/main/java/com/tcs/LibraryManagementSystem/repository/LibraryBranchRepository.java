package com.tcs.LibraryManagementSystem.repository;

import com.tcs.LibraryManagementSystem.entity.LibraryBranch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibraryBranchRepository extends JpaRepository<LibraryBranch, Integer> {

}